// ===== REGISTRO DEL SERVICE WORKER =====
if (navigator.serviceWorker) {
    // Usamos la ruta absoluta correspondiente a tu proyecto en el servidor local
    navigator.serviceWorker.register('/CV/sw.js');
}

// ===== CACHE STORAGE - PARTE 1 =====
// Descomenta UN bloque a la vez para probarlo.
if (window.caches) {

    // Actividad I: open, has y delete
    caches.open('Cache_de_prueba');
    caches.has('CachePrueba').then(console.log);
    caches.delete('Cache_de_prueba').then(console.log);

    /*
    // Agregar uno o más elementos a una caché
    caches.open('cache_elementos_app').then(cache => {
        cache.addAll([
            '/CV/',
            '/CV/index.html',
            '/CV/css/style.css',
            '/CV/img/utsoe.jpg'
        ]);
    });
    */

    /*
    // Borrar un elemento
    caches.open('cache_elementos_app').then(cache => {
        cache.addAll([
            '/CV/index.html',
            '/CV/css/style.css',
            '/CV/img/utsoe.jpg'
        ]).then(() => {
            cache.delete('/CV/img/utsoe.jpg');
        });
    });
    */

    /*
    // Leer un archivo de la caché y reemplazarlo
    caches.open('cache_elementos_app').then(cache => {
        cache.match('/CV/index.html')
            .then(res => {
                res.text().then(console.log);
            });

        // Reemplazar
        cache.put('/CV/index.html', new Response('Hola Mundo'));
    });
    */

    /*
    // Obtener todas las cachés de la aplicación
    caches.keys().then(keys => {
        console.log(keys);
    });
    */
}
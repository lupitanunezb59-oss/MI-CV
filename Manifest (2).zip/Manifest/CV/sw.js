// ===== CACHE STORAGE - PARTE II: APPSHELL =====
self.addEventListener('install', e => {
    const respuestaCaché = caches.open('cacheAppShell').then(cache => {
        return cache.addAll([
            '/CV/',
            '/CV/index.html',
            '/CV/css/style.css',
            '/CV/js/app.js',
            '/CV/img/utsoe.jpg',
            '/CV/UTSOE.png',
            '/CV/manifest.json'
        ]);
    });

    e.waitUntil(respuestaCaché);
});

// ===== ACTIVIDAD II: ESTRATEGIA DE CACHÉ =====
self.addEventListener('fetch', e => {
    // Busca primero en la caché, si no está, intenta ir a la red
    const respuesta = caches.match(e.request).then(resCache => {
        if (resCache) {
            return resCache;
        }
        // Si no está en caché, va a la red de forma segura
        return fetch(e.request).catch(err => {
            console.log('Fallo de red y recurso no cacheado:', e.request.url);
        });
    });

    e.respondWith(respuesta);
});